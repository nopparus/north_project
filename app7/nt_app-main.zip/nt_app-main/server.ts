import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("survey.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS sites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT,
    circuit_id TEXT,
    location TEXT,
    sub_district TEXT,
    district TEXT,
    province TEXT,
    region TEXT,
    department TEXT,
    section TEXT,
    latitude REAL,
    longitude REAL,
    ip_address TEXT,
    electricity_request TEXT,
    power_source TEXT,
    survey_cost REAL,
    survey_notes TEXT,
    survey_date TEXT,
    is_surveyed INTEGER DEFAULT 0,
    has_consumer_unit INTEGER DEFAULT 0,
    has_ground_rod INTEGER DEFAULT 0,
    consumer_unit_cost REAL,
    ground_rod_cost REAL,
    main_wire_rate REAL,
    main_wire_length REAL,
    labor_cost REAL
  )
`);

// Add new columns if they don't exist (for existing DBs)
try { db.exec("ALTER TABLE sites ADD COLUMN has_consumer_unit INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN has_ground_rod INTEGER DEFAULT 0"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN consumer_unit_cost REAL"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN ground_rod_cost REAL"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN main_wire_rate REAL"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN main_wire_length REAL"); } catch (e) {}
try { db.exec("ALTER TABLE sites ADD COLUMN labor_cost REAL"); } catch (e) {}

// Seed data if empty
const count = db.prepare("SELECT COUNT(*) as count FROM sites").get() as { count: number };
if (count.count === 0) {
  const insert = db.prepare(`
    INSERT INTO sites (
      request_id, circuit_id, location, sub_district, district, province, 
      region, department, section, latitude, longitude, ip_address, 
      electricity_request, power_source
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // Sample data from the screenshot
  const sampleData = [
    ["SR664609", "7561d9014", "หมู่ 4 ทุ่งหยีเพ็ง", "ศาลาด่าน", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.58866464, 99.0685061, "172.30.84.90", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664610", "7561d9000", "หมู่ 2 คลองหมาก", "เกาะลันตาน้อย", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.67506521, 99.0849853, "172.30.84.2", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664614", "7561d9015", "หมู่ 1 ร่าปู", "เกาะกลาง", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.71967138, 99.0888959, "172.30.84.242", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664623", "7561d9016", "หมู่ 1 เขาฝาก", "คลองยาง", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.79945411, 99.0803951, "172.30.84.246", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664624", "7561d9017", "หมู่ 3 โคกยูง", "คลองยาง", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.79071527, 99.1145529, "172.30.84.18", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664625", "7561d9018", "หมู่ 5 หลังโสด", "คลองยาง", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.84127398, 99.0649257, "172.30.84.250", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664626", "7561d9019", "หมู่ 6 ท่าควน", "คลองยาง", "เกาะลันตา", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 7.82719674, 99.0533436, "172.30.84.254", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664634", "7561d9021", "หมู่ 7 ควนพน", "เขาดิน", "เขาพนม", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 8.34613873, 99.1074244, "172.30.84.198", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664636", "7561d9022", "หมู่ 9 ปากบางสร้าน", "เขาดิน", "เขาพนม", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 8.34357, 99.0275021, "172.30.84.202", "บรรจบไฟฟ้า", "กฟภ."],
    ["SR664638", "7561d9023", "หมู่ 2 ห้วยสาร", "สินปุน", "เขาพนม", "กระบี่", "ตบ.", "ตบ.1", "บตบ.1 (กบ.)", 8.25618, 99.25317, "172.30.84.94", "บรรจบไฟฟ้า", "กฟภ."],
  ];

  for (const row of sampleData) {
    insert.run(...row);
  }

  // Generate more mock data for other provinces to demonstrate filtering
  const provinces = ["ภูเก็ต", "พังงา", "สุราษฎร์ธานี", "นครศรีธรรมราช"];
  const districts = ["เมือง", "ถลาง", "กะทู้", "ตะกั่วป่า", "ท้ายเหมือง", "เกาะสมุย", "พุนพิน"];
  
  for (let i = 0; i < 200; i++) {
    const p = provinces[Math.floor(Math.random() * provinces.length)];
    const d = districts[Math.floor(Math.random() * districts.length)];
    const lat = 7 + Math.random() * 2;
    const lng = 98 + Math.random() * 2;
    insert.run(
      `SR${664640 + i}`, 
      `7561d${9024 + i}`, 
      `หมู่ที่ ${Math.floor(Math.random() * 10) + 1} ทดสอบ`, 
      "ตำบลทดสอบ", 
      d, 
      p, 
      "ตบ.", "ตบ.1", "บตบ.1", 
      lat, lng, 
      `172.30.84.${Math.floor(Math.random() * 254)}`, 
      "บรรจบไฟฟ้า", "กฟภ."
    );
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/sites", (req, res) => {
    const { province, district, status } = req.query;
    let query = "SELECT * FROM sites WHERE 1=1";
    const params: any[] = [];

    if (province) {
      query += " AND province = ?";
      params.push(province);
    }
    if (district) {
      query += " AND district = ?";
      params.push(district);
    }
    if (status === "surveyed") {
      query += " AND is_surveyed = 1";
    } else if (status === "pending") {
      query += " AND is_surveyed = 0";
    }

    const sites = db.prepare(query).all(...params);
    res.json(sites);
  });

  app.get("/api/filters", (req, res) => {
    const provinces = db.prepare("SELECT DISTINCT province FROM sites ORDER BY province").all();
    const districts = db.prepare("SELECT DISTINCT province, district FROM sites ORDER BY province, district").all();
    res.json({ provinces, districts });
  });

  app.post("/api/survey/:id", (req, res) => {
    const { id } = req.params;
    const { cost, notes, consumerUnitCost, groundRodCost, mainWireRate, mainWireLength, laborCost } = req.body;
    const date = new Date().toISOString();

    const result = db.prepare(`
      UPDATE sites 
      SET survey_cost = ?, 
          survey_notes = ?, 
          survey_date = ?, 
          is_surveyed = 1,
          consumer_unit_cost = ?,
          ground_rod_cost = ?,
          main_wire_rate = ?,
          main_wire_length = ?,
          labor_cost = ?
      WHERE id = ?
    `).run(
      cost, 
      notes, 
      date, 
      consumerUnitCost, 
      groundRodCost, 
      mainWireRate,
      mainWireLength, 
      laborCost, 
      id
    );

    if (result.changes > 0) {
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Site not found" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
